# Changelog

## 1.0.0 — 2026-09-25

- Initial modular theme, core editorial plugin, and optional Live/TV plugin.
- Responsive editorial templates, accessible mobile drawer, search panel, article and archives.
- Breaking/ticker, video content type, social links, safe ad slots, basic view counter, SEO fallback, and NewsArticle schema.
- Channel/program management and constrained YouTube/Vimeo/HLS/MP4 player output.
