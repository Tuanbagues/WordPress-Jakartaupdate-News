#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="$(dirname "$PWD")"
rm -f "$OUT/jakartaupdate.zip" "$OUT/jakartaupdate-core.zip" "$OUT/jakartaupdate-live.zip" "$OUT/jakartaupdate-framework-1.0.0.zip"
zip -qr "$OUT/jakartaupdate.zip" jakartaupdate
zip -qr "$OUT/jakartaupdate-core.zip" jakartaupdate-core
zip -qr "$OUT/jakartaupdate-live.zip" jakartaupdate-live
zip -qr "$OUT/jakartaupdate-framework-1.0.0.zip" jakartaupdate README.md INSTALL.md ADMIN-GUIDE.md DEVELOPMENT.md LIVE-TV.md CUSTOMIZATION.md SECURITY.md PERFORMANCE.md CHANGELOG.md PRODUCTION-REPORT.md package.sh
