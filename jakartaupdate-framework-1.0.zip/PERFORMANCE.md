# Performance notes

The theme uses WordPress responsive image functions, lazy thumbnail loading, no external frontend framework, and small deferred-footer scripts. The Live stylesheet loads only when a singular page includes `[ju_live_tv]`; iframe/video players are not loaded site-wide. Editorial queries use `no_found_rows` for fixed-size sections. Use image optimization, a page/object cache and CDN at the host level. Measure Core Web Vitals on production-like content and ensure the hero image is appropriately compressed and dimensioned.
