# Customization

Use a child theme for template or style overrides; do not edit the parent theme for site-specific changes. The primary and footer menus are registered in WordPress. The logo is managed with the native Custom Logo feature. The header's desktop sequence is logo, menu, search and LIVE; mobile is logo, search, LIVE and drawer.

Colors and layout are defined with CSS variables at the start of `assets/css/main.css`. Components use `.ju-` naming to reduce collisions. Live page URL and dark-mode preference are under the theme Customizer section. Dark mode sets a data attribute but a complete polished palette and visible user toggle are not included in this starter release.
