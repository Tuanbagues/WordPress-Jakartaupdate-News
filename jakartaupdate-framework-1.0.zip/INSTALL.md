# Installation and first setup

1. Back up the WordPress site and test on staging. Confirm PHP 8.1+ and WordPress 6.2+.
2. In **Appearance → Themes → Add New → Upload Theme**, upload `jakartaupdate.zip`, then activate it.
3. In **Plugins → Add New → Upload Plugin**, upload `jakartaupdate-core.zip`, activate it, and open **JakartaUpdate → Settings**.
4. Optionally upload and activate `jakartaupdate-live.zip`.
5. Set a site title/tagline, logo, menus, homepage and category structure. Recommended category slugs are `news`, `market`, `sport`, and `lifestyle`.
6. For TV: create a **Live** page containing `[ju_live_tv]`, create a channel, configure HTTPS stream URL and actual stream status, then set the Live URL in **Appearance → Customize → JakartaUpdate**.
7. Configure ad, social and analytics IDs only when applicable. Test with a private browser window, mobile device, and staging cache enabled.

The theme does not silently install plugins or overwrite existing site settings. To make the posts archive the front page, set **Settings → Reading** accordingly.
