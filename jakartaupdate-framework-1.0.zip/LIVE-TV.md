# LIVE / TV Online

Activate `jakartaupdate-live`, add a WordPress page called **Live**, and insert `[ju_live_tv]`. Each Channel supports YouTube Live, HTTPS HLS/M3U8 and MP4; constrained embed mode accepts YouTube/Vimeo only. The player uses native HTML5 video for HLS/MP4, `preload="none"`, responsive sizing, and lazy iframe loading. No player library is loaded site-wide.

Create a channel through **Channels → Add Channel**, then set player type, stream URL and status. `ON AIR` is rendered only for an `on_air` channel with a valid URL; otherwise it reports scheduled/off air or an unavailable message. Programs link to a channel and store date and times. For reliable schedules, use the site's WordPress timezone and keep the entries current.

Autoplay is intentionally not forced. Browser policies and HLS codec/CDN support differ; native HLS may not play in every browser. Use an HTTPS CDN/stream provider and test playback, CORS, MIME type and mobile behavior on the target hosting.
