# Administrator guide

Core settings are grouped at **JakartaUpdate → Settings**. Use the Breaking panel to enable the ribbon, set its label, and optionally enter comma-separated post IDs; if the list is empty, the newest stories appear. The ticker is independently toggleable. Social URL fields render links in the footer. Ad slots accept WordPress-safe HTML; script and iframe ad tags may be stripped by sanitization, which is intentional for security. Analytics fields accept IDs, not arbitrary scripts.

Mark a post as breaking from its JakartaUpdate sidebar metabox. Add videos using **Video News** and set a YouTube/Vimeo/MP4 URL in the video URL field. Theme sections for Market/Sport/Lifestyle appear when those category slugs exist. Homepage layout is intentionally conservative and code-defined in this first release; there is not yet a drag-and-drop section builder.

Settings export is available at **JakartaUpdate → Import / Export**. The current tool exports settings JSON only. Import, channel export, a guided wizard, granular reporting, date-window view analytics, and expanded system checks are future work, rather than silently modifying a site's data.
