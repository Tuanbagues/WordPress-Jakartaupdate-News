# Development notes

Keep presentation in the theme and editorial/media data in plugins. Prefix PHP functions with `ju_` and options/meta with `_ju_`. Prefer native WordPress APIs and escape at output boundaries. Do not add external dependencies without a documented reason.

## Local checks

- Run `php -l` on each PHP source file.
- Install the ZIPs on a disposable WordPress site using PHP 8.1+.
- Test theme activation with Core absent and present; test Live absent and present.
- Test mobile header order at 320–414 px and desktop navigation at 1024–1440 px.
- Verify menu keyboard behavior, search, post cards, article, category archives, and no-stream fallback.

For release, add automated WordPress integration tests, PHPCS with WordPress rules, accessibility checks, Lighthouse/Core Web Vitals, and tests against supported SEO/caching plugins.
