<?php
/**
 * Plugin Name: JakartaUpdate Live & TV
 * Description: Channel and program manager with responsive YouTube, HLS, MP4 and approved video-embed players.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 8.1
 * Author: JakartaUpdate
 * Text Domain: jakartaupdate-live
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'JU_LIVE_VERSION', '1.0.0' );
require_once __DIR__ . '/includes/live.php';
