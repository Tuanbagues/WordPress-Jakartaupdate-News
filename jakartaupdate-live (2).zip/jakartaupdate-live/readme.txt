=== JakartaUpdate Live & TV ===
Contributors: jakartaupdate
Requires at least: 6.2
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later

Manage channels and program schedules. Supports YouTube Live, HTTPS HLS/M3U8, MP4, and validated YouTube/Vimeo embeds.

Create channels under **Channels → Add Channel**, set stream type, HTTPS URL and status. Create a WordPress page titled Live and add `[ju_live_tv]`; optionally pass a channel ID as `[ju_live_tv channel="123"]`. Select this URL in Appearance → Customize → JakartaUpdate for the header LIVE button.
