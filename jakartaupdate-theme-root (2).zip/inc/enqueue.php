<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function ju_theme_assets() {
    $uri = get_template_directory_uri();
    wp_enqueue_style( 'jakartaupdate-style', get_stylesheet_uri(), array(), JU_THEME_VERSION );
    wp_enqueue_style( 'jakartaupdate-main', $uri . '/assets/css/main.css', array( 'jakartaupdate-style' ), JU_THEME_VERSION );
    wp_enqueue_script( 'jakartaupdate-navigation', $uri . '/assets/js/navigation.js', array(), JU_THEME_VERSION, true );
    wp_enqueue_script( 'jakartaupdate-main', $uri . '/assets/js/main.js', array(), JU_THEME_VERSION, true );
    wp_localize_script( 'jakartaupdate-main', 'juTheme', array( 'darkMode' => get_theme_mod( 'ju_dark_mode', 'system' ) ) );
}
add_action( 'wp_enqueue_scripts', 'ju_theme_assets' );
function ju_theme_customize( $wp_customize ) {
    $wp_customize->add_section( 'ju_theme_options', array( 'title' => __( 'JakartaUpdate', 'jakartaupdate' ), 'priority' => 35 ) );
    $wp_customize->add_setting( 'ju_live_url', array( 'default' => home_url( '/live/' ), 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( 'ju_live_url', array( 'label' => __( 'Live page URL', 'jakartaupdate' ), 'section' => 'ju_theme_options', 'type' => 'url' ) );
    $wp_customize->add_setting( 'ju_dark_mode', array( 'default' => 'system', 'sanitize_callback' => function( $value ) { return in_array( $value, array( 'disabled', 'manual', 'system' ), true ) ? $value : 'system'; } ) );
    $wp_customize->add_control( 'ju_dark_mode', array( 'label' => __( 'Dark mode', 'jakartaupdate' ), 'section' => 'ju_theme_options', 'type' => 'select', 'choices' => array( 'disabled' => 'Disabled', 'manual' => 'Manual', 'system' => 'Follow system' ) ) );
}
add_action( 'customize_register', 'ju_theme_customize' );
