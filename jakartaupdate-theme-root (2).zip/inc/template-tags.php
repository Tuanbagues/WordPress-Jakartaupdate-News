<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function ju_posted_meta() {
    echo '<span class="ju-meta-date">' . esc_html( get_the_date() ) . '</span>';
    if ( function_exists( 'ju_get_post_views' ) ) { echo ' <span class="ju-meta-views">' . esc_html( number_format_i18n( ju_get_post_views( get_the_ID() ) ) ) . ' views</span>'; }
}
function ju_post_card( $variant = 'standard' ) {
    get_template_part( 'template-parts/post-card', $variant );
}
