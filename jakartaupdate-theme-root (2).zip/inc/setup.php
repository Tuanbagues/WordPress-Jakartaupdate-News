<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function ju_theme_setup() {
    load_theme_textdomain( 'jakartaupdate', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 300, 'flex-height' => true, 'flex-width' => true ) );
    add_theme_support( 'align-wide' );
    register_nav_menus( array( 'primary' => __( 'Primary navigation', 'jakartaupdate' ), 'footer' => __( 'Footer navigation', 'jakartaupdate' ) ) );
    add_image_size( 'ju-hero', 1200, 720, true );
    add_image_size( 'ju-card', 640, 420, true );
}
add_action( 'after_setup_theme', 'ju_theme_setup' );
function ju_fallback_menu() { echo '<ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'jakartaupdate' ) . '</a></li><li><a href="' . esc_url( home_url( '/category/news/' ) ) . '">' . esc_html__( 'News', 'jakartaupdate' ) . '</a></li><li><a href="' . esc_url( home_url( '/category/market/' ) ) . '">' . esc_html__( 'Market', 'jakartaupdate' ) . '</a></li><li><a href="' . esc_url( home_url( '/category/sport/' ) ) . '">' . esc_html__( 'Sport', 'jakartaupdate' ) . '</a></li><li><a href="' . esc_url( home_url( '/category/lifestyle/' ) ) . '">' . esc_html__( 'Lifestyle', 'jakartaupdate' ) . '</a></li></ul>'; }
function ju_theme_content_width() { $GLOBALS['content_width'] = apply_filters( 'ju_theme_content_width', 820 ); }
add_action( 'after_setup_theme', 'ju_theme_content_width', 0 );
