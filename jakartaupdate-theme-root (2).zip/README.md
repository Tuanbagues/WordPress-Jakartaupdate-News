# JakartaUpdate WordPress Theme

A mobile-first editorial theme for news publishers. The theme is the presentation layer; install `jakartaupdate-core` and optionally `jakartaupdate-live` for editorial features and TV streaming.

## Requirements

WordPress 6.2+, PHP 8.0+, HTTPS recommended. Uses WordPress template and menu APIs and vanilla JavaScript. No external front-end framework is required.

## Install

Upload `jakartaupdate.zip` under **Appearance → Themes → Add New → Upload Theme**, then activate. Set a logo and menus under **Appearance → Customize** and **Appearance → Menus**. Add a page named “Live” and place `[ju_live_tv]` on it when the Live plugin is enabled.

## Header

Desktop order: logo, primary navigation, search, LIVE. Mobile order: logo, search, LIVE, menu. The mobile drawer supports Escape, backdrop click, focus return/trap, body scroll lock and ARIA state. Assign menu links in WordPress; the theme supplies safe fallback links.

See `INSTALL.md`, `ADMIN-GUIDE.md`, `LIVE-TV.md` and `SECURITY.md` in the project bundle.
