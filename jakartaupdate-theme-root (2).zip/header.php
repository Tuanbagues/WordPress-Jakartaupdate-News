<!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class( 'ju-site' ); ?>><?php wp_body_open(); ?>
<a class="ju-skip-link" href="#ju-main"><?php esc_html_e( 'Skip to content', 'jakartaupdate' ); ?></a>
<header class="ju-header" role="banner"><div class="ju-header-inner">
  <div class="ju-brand"><?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?><a class="ju-wordmark" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">JAKARTA<span>UPDATE</span></a><?php } ?></div>
  <nav class="ju-desktop-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'jakartaupdate' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'ju_fallback_menu', 'depth' => 2 ) ); ?></nav>
  <div class="ju-header-actions">
    <button class="ju-search-toggle" type="button" aria-label="<?php esc_attr_e( 'Open search', 'jakartaupdate' ); ?>" aria-expanded="false" aria-controls="ju-search-panel"><span aria-hidden="true">⌕</span></button>
    <a class="ju-live-link" href="<?php echo esc_url( get_theme_mod( 'ju_live_url', home_url( '/live/' ) ) ); ?>"><span class="ju-live-dot" aria-hidden="true"></span><span><?php esc_html_e( 'LIVE', 'jakartaupdate' ); ?></span></a>
    <button class="ju-menu-toggle" type="button" aria-label="<?php esc_attr_e( 'Open menu', 'jakartaupdate' ); ?>" aria-expanded="false" aria-controls="ju-mobile-drawer"><span></span><span></span><span></span></button>
  </div>
</div>
<div id="ju-search-panel" class="ju-search-panel" hidden><?php get_search_form(); ?></div>
<div class="ju-drawer-backdrop" data-ju-close hidden></div>
<aside id="ju-mobile-drawer" class="ju-mobile-drawer" aria-label="<?php esc_attr_e( 'Mobile menu', 'jakartaupdate' ); ?>" aria-hidden="true" inert>
  <button class="ju-drawer-close" type="button" aria-label="<?php esc_attr_e( 'Close menu', 'jakartaupdate' ); ?>">×</button>
  <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => 'nav', 'container_aria_label' => __( 'Mobile navigation', 'jakartaupdate' ), 'fallback_cb' => 'ju_fallback_menu', 'depth' => 2 ) ); ?>
  <nav aria-label="<?php esc_attr_e( 'More media', 'jakartaupdate' ); ?>"><ul><li><a href="<?php echo esc_url( home_url( '/video/' ) ); ?>">VIDEO</a></li><li><a href="<?php echo esc_url( get_theme_mod( 'ju_live_url', home_url( '/live/' ) ) ); ?>">TV ONLINE</a></li><li><a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ?: home_url( '/' ) ); ?>">CATEGORY</a></li></ul></nav>
</aside></header>
