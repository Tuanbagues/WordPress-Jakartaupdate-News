<?php
/** JakartaUpdate theme bootstrap. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'JU_THEME_VERSION', '1.0.0' );
require_once get_template_directory() . '/inc/setup.php';
require_once get_template_directory() . '/inc/enqueue.php';
require_once get_template_directory() . '/inc/template-tags.php';
