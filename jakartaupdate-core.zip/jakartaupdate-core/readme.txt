=== JakartaUpdate Core ===
Contributors: jakartaupdate
Requires at least: 6.2
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later

Editorial tools, breaking ribbon, ticker, video post type, social links, safe ad slots, basic view counts and metadata fallback.

Activate the plugin and configure **JakartaUpdate → Settings**. For best results use the JakartaUpdate theme. SEO metadata and NewsArticle schema are suppressed when a common SEO plugin is detected.
