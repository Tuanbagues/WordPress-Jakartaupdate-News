<?php
/**
 * Plugin Name: JakartaUpdate Core
 * Description: Editorial tools, homepage modules, advertising slots and social features for JakartaUpdate.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 8.1
 * Author: JakartaUpdate
 * Text Domain: jakartaupdate-core
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'JU_CORE_VERSION', '1.0.0' );
require_once __DIR__ . '/includes/core.php';
